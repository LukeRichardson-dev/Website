from asyncio import futures
from concurrent.futures import ThreadPoolExecutor

from authorisation.auth_pb2_grpc import add_AuthServicer_to_server
from .base import engine, Base
from .service import AuthService
import grpc


def main():
    Base.metadata.create_all(engine)

    server = grpc.server(ThreadPoolExecutor(max_workers=1))

    add_AuthServicer_to_server(AuthService(), server)

    server.add_insecure_port('localhost:9000')
    server.start()

    print('Server started on localhost:9000')

    server.wait_for_termination()

if __name__ == '__main__':
    main()