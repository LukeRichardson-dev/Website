# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['authorisation']

package_data = \
{'': ['*']}

install_requires = \
['PyJWT[crypto]>=2.3.0,<3.0.0',
 'SQLAlchemy>=1.4.31,<2.0.0',
 'cryptography>=36.0.1,<37.0.0',
 'grpcio>=1.44.0,<2.0.0',
 'psycopg2>=2.9.2,<3.0.0']

entry_points = \
{'console_scripts': ['run-service = authorisation.entrypoint:main']}

setup_kwargs = {
    'name': 'authorisation',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'lukerichardson-dev',
    'author_email': 'richardsonluke232@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
